export async function addResponse({
  id,
  status,
  headers,
  body,
}) {
  const { HttpConn } = this.model;
  const timestamp = new Date(this.timestamp).toISOString();

  const response = {
    timestamp,
    status,
    headers,
    body,
  };

  const httpConn = await HttpConn.node(id).update({ response });

  return { httpConn };
}
