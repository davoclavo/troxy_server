
export async function addHttpConn({
  method,
  host,
  port,
  scheme,
  headers,
  path,
  body,
}) {
  const { HttpConn } = this.model;
  const timestamp = new Date(this.timestamp).toISOString();

  const request = {
    method,
    host,
    port,
    scheme,
    headers,
    path,
    body,
  };

  const httpConn = await HttpConn.addNode({ timestamp, request });

  return { httpConn };
}
